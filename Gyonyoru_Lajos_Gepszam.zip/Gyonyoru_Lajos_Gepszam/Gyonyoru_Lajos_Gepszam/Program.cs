﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Gyonyoru_Lajos_Gepszam
{
    static class Program
    {
        public static Form_Navigalo form_navigalo = null;
        public static Form_Kesesek form_kesesek = null;
        public static Form_Kolcsonzes form_kolcsonzes = null;
        public static MySqlConnection conn = null;
        public static MySqlCommand sql = null;
        static void Main()
        {
            MySqlConnectionStringBuilder sb = new MySqlConnectionStringBuilder();
            sb.Server = "localhost";
            sb.UserID = "root";
            sb.Password = "";
            sb.Database = "bagolyvar";
            sb.CharacterSet = "UTF8";
            conn = new MySqlConnection(sb.ToString());
            try
            {
                conn.Open();
                sql = conn.CreateCommand();
            }
            catch (MySqlException myex)
            {
                Console.WriteLine("Az adatbázis nem érhető el!\n"+myex.Message);
                Console.ReadKey();
                Environment.Exit(0);
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            form_navigalo = new Form_Navigalo();
            form_kolcsonzes = new Form_Kolcsonzes();
            form_kesesek = new Form_Kesesek();
            Application.Run(form_navigalo);
        }
    }
}
